#!/usr/bin/env python3
r"""PINAKA M05 "Vaidehi -- The Sealed Covenant" -- PUBLIC covenant primitive.

This is the exact client-side protocol module the Council of Mithila's covenant-registry ships.
It contains NO secrets: no council member secret key, no nonce scalar, no aggregate secret --
only the public secp256k1 arithmetic, the MuSig key-aggregation rule, the Schnorr challenge the
registry uses, and the seal verifier. Load the public parameters and the covenant from the JSON
instance files that accompany this module (params.json, instance.json).

PROTOCOL  (MuSig-style Schnorr multisignature, non-interactive via Fiat-Shamir)
-------------------------------------------------------------------------------
The Council of Mithila is three members with public keys X_1, X_2, X_3. Keys aggregate (MuSig)
to  X = sum_i a_i * X_i  with coefficients a_i = H(L, X_i), L = H(X_1,X_2,X_3). A covenant
revision is sealed by a Schnorr multisignature (R, s); it is valid for (doc_id, revision, body)
iff
    s*G == R + e*X   (mod the curve),   e = H(R, X, doc_id, revision, body).

The arithmetic is secp256k1 (via py_ecc). Points are [x, y] integer pairs; scalars are integers
mod n. This module provides key_agg(), challenge(), and verify_seal(); prove_seal() is included
only so the protocol is fully specified -- it requires the aggregate secret, which players do
not hold.
"""
import json, os, hashlib
from py_ecc.secp256k1 import secp256k1 as C

_HERE = os.path.dirname(os.path.abspath(__file__))
G, N = C.G, C.N


def load_params(path=None):
    with open(path or os.path.join(_HERE, "params.json")) as f:
        return json.load(f)


def load_instance(path=None):
    with open(path or os.path.join(_HERE, "instance.json")) as f:
        return json.load(f)


def mul(Pt, k):
    return C.multiply(Pt, k % N)


def add(P1, P2):
    return C.add(P1, P2)


def _h(*parts):
    m = hashlib.sha256(b"PINAKA-M05-COVENANT")
    for x in parts:
        m.update(b"|")
        m.update(str(x).encode())
    return int(m.hexdigest(), 16) % N


def key_agg(pubkeys):
    """MuSig aggregate key from a list of public keys [[x,y], ...]. Returns (X, coeffs)."""
    pubkeys = [tuple(p) for p in pubkeys]
    L = _h("L", *[p for X in pubkeys for p in (X[0], X[1])])
    coeffs = [_h("coef", L, X[0], X[1]) for X in pubkeys]
    X = None
    for a, Xi in zip(coeffs, pubkeys):
        term = mul(Xi, a)
        X = term if X is None else add(X, term)
    return X, coeffs


# ---- the Schnorr challenge the registry uses to seal a covenant revision -------------------
#
# NOTE for researchers: the challenge binds the aggregate nonce R, the aggregate key X, and the
# FULL message (doc_id, revision, body). It is well-formed. What is worth studying is not the
# challenge but the SESSION in which R is produced -- see params.json "session_rule".
def challenge(R, X, doc_id, revision, body):
    R = tuple(R); X = tuple(X)
    return _h("e", R[0], R[1], X[0], X[1], doc_id, revision, body)


def verify_seal(X, doc_id, revision, body, seal):
    """Verify a MuSig Schnorr seal (R,s) for (doc_id, revision, body). Returns bool."""
    X = tuple(X)
    try:
        R = (int(seal["R"][0]), int(seal["R"][1]))
        s = int(seal["s"])
    except (KeyError, TypeError, ValueError, IndexError):
        return False
    if not (0 < s < N):
        return False
    e = challenge(R, X, doc_id, revision, body)
    return mul(G, s) == add(R, mul(X, e))


def prove_seal(X, x_agg, doc_id, revision, body, nonce):
    """Honest sealer. REQUIRES the aggregate secret x_agg and a per-revision nonce scalar.
    Provided so the protocol is fully specified; players do not hold the council's secret."""
    R = mul(G, nonce)
    e = challenge(R, X, doc_id, revision, body)
    return {"R": [R[0], R[1]], "s": (nonce + e * x_agg) % N}


if __name__ == "__main__":
    # self-check: the shipped aggregate key matches key_agg over the council keys, and each
    # genuine (leaked) seal verifies for its ratified revision.
    params = load_params()
    inst = load_instance()
    X_i = [m["pubkey"] for m in params["council"]]
    X, _ = key_agg(X_i)
    assert [X[0], X[1]] == params["aggregate_key"], "aggregate key mismatch"
    print("aggregate key reproduces params.aggregate_key: True")
    for rev in inst["ratified_revisions"]:
        ok = verify_seal(X, inst["doc_id"], rev["revision"], rev["body"], rev["seal"])
        print(f"ratified revision {rev['revision']} seal verifies: {ok}")
