#!/usr/bin/env python3
import json, os, hashlib, secrets

_HERE = os.path.dirname(os.path.abspath(__file__))


def load_params(path=None):
    with open(path or os.path.join(_HERE, "params.json")) as f:
        return json.load(f)


def load_instance(path=None):
    with open(path or os.path.join(_HERE, "instance.json")) as f:
        return json.load(f)


def _h_bind(ctx, Y0, Y1, q):
    m = hashlib.sha256(b"PINAKA-M02-FS")
    for lbl, v in (("ctx", ctx), ("Y0", Y0), ("Y1", Y1)):
        m.update(b"|"); m.update(lbl.encode()); m.update(b"|"); m.update(str(v).encode())
    return int(m.hexdigest(), 16) % q


def _h_bind_full(ctx, Y0, Y1, t0, t1, q):
    m = hashlib.sha256(b"PINAKA-M02-FS-v2")
    for lbl, v in (("ctx", ctx), ("Y0", Y0), ("Y1", Y1), ("t0", t0), ("t1", t1)):
        m.update(b"|"); m.update(lbl.encode()); m.update(b"|"); m.update(str(v).encode())
    return int(m.hexdigest(), 16) % q


def _h_bind_augmented(ctx, Y0, Y1, t0, t1, epoch, q):
    m = hashlib.sha256(b"PINAKA-M02-FS-aug")
    for lbl, v in (("ctx", ctx), ("Y0", Y0), ("Y1", Y1), ("t0", t0), ("t1", t1), ("ep", epoch)):
        m.update(b"|"); m.update(lbl.encode()); m.update(b"|"); m.update(str(v).encode())
    return int(m.hexdigest(), 16) % q


def _select_binding(params, *args):
    mode = params.get("binding_mode", 0)
    if mode == 0:
        return _h_bind(args[0], args[1], args[2], args[5])
    elif mode == 1:
        return _h_bind_full(*args)
    else:
        return _h_bind_augmented(*args, params.get("epoch", 0), args[5])


def verify(params, Y0, Y1, deposition):
    p, g, q, ctx = params["p"], params["g"], params["q"], params["ctx"]
    d = deposition
    t0, t1 = int(d["t0"]), int(d["t1"])
    c0, c1, s0, s1 = int(d["c0"]), int(d["c1"]), int(d["s0"]), int(d["s1"])
    Y0, Y1 = int(Y0), int(Y1)
    if not (0 < t0 < p and 0 < t1 < p):
        return False
    if not all(0 <= v < q for v in (c0, c1, s0, s1)):
        return False
    c = _select_binding(params, ctx, Y0, Y1, t0, t1, q)
    if (c0 + c1) % q != c % q:
        return False
    eq0 = pow(g, s0, p) == (t0 * pow(Y0, c0, p)) % p
    eq1 = pow(g, s1, p) == (t1 * pow(Y1, c1, p)) % p
    return eq0 and eq1


def verify_strict(params, Y0, Y1, deposition):
    p, g, q, ctx = params["p"], params["g"], params["q"], params["ctx"]
    d = deposition
    t0, t1 = int(d["t0"]), int(d["t1"])
    c0, c1, s0, s1 = int(d["c0"]), int(d["c1"]), int(d["s0"]), int(d["s1"])
    Y0, Y1 = int(Y0), int(Y1)
    if not (0 < t0 < p and 0 < t1 < p):
        return False
    if not all(0 <= v < q for v in (c0, c1, s0, s1)):
        return False
    c = _h_bind_full(ctx, Y0, Y1, t0, t1, q)
    if (c0 + c1) % q != c % q:
        return False
    eq0 = pow(g, s0, p) == (t0 * pow(Y0, c0, p)) % p
    eq1 = pow(g, s1, p) == (t1 * pow(Y1, c1, p)) % p
    return eq0 and eq1


def prove(params, Y0, Y1, known_branch, x):
    p, g, q, ctx = params["p"], params["g"], params["q"], params["ctx"]
    Ys = (int(Y0), int(Y1)); b = known_branch; o = 1 - b
    c = [0, 0]; s = [0, 0]; t = [0, 0]
    c[o] = secrets.randbelow(q); s[o] = secrets.randbelow(q)
    t[o] = (pow(g, s[o], p) * pow(Ys[o], (-c[o]) % q, p)) % p
    r = secrets.randbelow(q - 1) + 1
    t[b] = pow(g, r, p)
    cc = _select_binding(params, ctx, Ys[0], Ys[1], t[0], t[1], q)
    c[b] = (cc - c[o]) % q
    s[b] = (r + c[b] * x) % q
    return {"t0": t[0], "t1": t[1], "c0": c[0], "c1": c[1], "s0": s[0], "s1": s[1]}


if __name__ == "__main__":
    params = load_params()
    inst = load_instance()
    dk = inst["dockets"]["enrolled-nobles"]
    ok = verify(params, dk["identities"]["Y0"], dk["identities"]["Y1"], dk["specimen_deposition"])
    print(f"specimen deposition for 'enrolled-nobles' verifies: {ok}")
