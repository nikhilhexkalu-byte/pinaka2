# M02 - Janaka's Court: The False Witness

*In Mithila, King Janaka's court does not take a man at his word. To testify, a deponent must
enter a **deposition** - a sealed proof that he holds the seal-key of one of the court's enrolled
identities, yet without disclosing which, so that no noble is made to name himself. The clerk
admits the testimony only if its seal is whole. But a seal is only as honest as the question it
answers - and the clerk, in his haste, asks a question that is settled before the witness has
said a single word.*

## Target

A single HTTP/JSON service - the **court-clerk validator**. Connection details for your instance
are provided by the platform.

Public endpoints:

| Method / path | What it returns |
|---|---|
| `GET /court/params` | Group parameters and the court context. |
| `GET /court/registry` | The docket registry (each docket's identity pair), a **specimen deposition** for an enrolled docket, and the **forbidden target** docket. |
| `POST /court/depose` | Body `{"docket": <name>, "deposition": {"t0","t1","c0","c1","s0","s1"}}`. The clerk verifies your deposition against that docket's identity pair. |

The court's testimony primitive (`pinaka_testimony.py`) and the instance files (`params.json`,
`instance.json`) ship alongside this brief.

## Goal

Make the court admit a deposition for the **forbidden docket** (`false-witness`) - whose two
identities are **nullified seals** that no one holds the key to, so no honest deponent could ever
testify to it. You must enter a **valid deposition for that docket** using only what is public:
the parameters, the registry, and the testimony primitive. You hold **no seal exponent, no secret
key, no witness**.

Submit your deposition to `POST /court/depose` with `"docket": "false-witness"`. The clerk
validates server-side and returns the court's proclamation (the flag) only when a genuinely
verifying proof for the forbidden identity pair is presented. There is no flag in any file.
