# M04 - Dhanurbhanga: The Fractured Invariant

*In the court of Janaka at Mithila stands Pinaka, the bow of Shiva - so vast no mortal has ever
bent it. Its tension is bound by a sacred law, an invariant the royal astrologers can prove will
hold through any lawful draw: by their reckoning the bow can **never** reach the breaking point.
Yet Rama steps forward to break what cannot be broken.*

## What you are given

| File | What it is |
|---|---|
| `FORMAL_SPEC.md`   | The formal specification of the **Pinaka Tension Machine**: its state, its instruction set, its well-formedness grammar, and its acceptance state. |
| `formal_model.py`  | A reference implementation of that formal specification. Run it on any program to see the result. |
| `pinaka_check.c`   | **The real checker** - the exact machine the server runs. |
| `pinaka_check`     | The compiled checker binary (same program the server executes). |
| `pinaka_params.h`  | The public machine parameters `X0` and `TARGET`. |

Nothing here contains the flag.

## Your goal

Produce a **well-formed program** that the server's checker (`pinaka_check`) **accepts** - that
is, one whose final register equals `TARGET`.

Present that program to the seal below. The server runs the real checker on it and, only if the
checker accepts, the bow breaks and returns the flag for your instance.

## Submission

`POST /mithila/dhanurbhanga` with a JSON body:

```json
{ "program": "<hex bytes of a Pinaka Tension Machine program>" }
```
or
```json
{ "program_b64": "<the same bytes, base64>" }
```

On acceptance the response contains `"status": "bow-broken"` and the `flag`. Otherwise the bow
holds and no flag is returned.
