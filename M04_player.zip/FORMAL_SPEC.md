# The Pinaka Tension Machine - Formal Specification

This document specifies the **Pinaka Tension Machine** (PTM) as a transition system.

---

## 1. State

A configuration is a single register `x`, a non-negative integer. The machine starts from the
fixed initial register

```
x := X0          (see pinaka_params.h)
```

## 2. Program

A **program** is a byte string, executed left-to-right until a `HALT` opcode or the end of the
bytes. Immediates are **little-endian unsigned 64-bit**.

| Opcode | Mnemonic | Bytes            | Transition `x -> x'` |
|-------:|----------|------------------|----------------------|
| `0x00` | `HALT`   | `00`             | stop                 |
| `0x01` | `TRPL`   | `01`             | `x' = x * 3`        |
| `0x02` | `SQ`     | `02`             | `x' = x * x`        |
| `0x10` | `ADDK`   | `10` + `imm[8]`  | `x' = x + imm`      |
| `0x11` | `MULK`   | `11` + `imm[8]`  | `x' = x * imm`      |

## 3. Well-formedness

A program is **well-formed** iff **all** of the following hold:

1. every opcode is one of `{HALT, TRPL, SQ, ADDK, MULK}`;
2. every `ADDK` / `MULK` is followed by a complete 8-byte immediate;
3. **every immediate `imm` satisfies `imm % 3 == 0`**;
4. the program is at most `MAX_PROG_BYTES = 4096` bytes;
5. at most `MAX_STEPS = 1024` opcodes are executed.

Ill-formed programs are rejected.

## 4. Acceptance

The machine has one distinguished acceptance state:

```
accept  <=>  the program is well-formed  AND  the halting register x equals TARGET
```

where `TARGET` is the public constant in `pinaka_params.h`.

## 5. Properties

The formal model (`formal_model.py`) and the compiled checker (`pinaka_check`) both implement
this machine. They both enforce identical well-formedness rules. Study both implementations
carefully.
