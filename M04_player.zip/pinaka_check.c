#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#include "pinaka_params.h"

#define OP_HALT 0x00u
#define OP_TRPL 0x01u
#define OP_SQ   0x02u
#define OP_ADDK 0x10u
#define OP_MULK 0x11u

#define MAX_PROG_BYTES 4096u
#define MAX_STEPS      1024u
#define INV_MOD        3u

static unsigned char prog[MAX_PROG_BYTES];

static uint64_t load_le64(const unsigned char *p) {
    uint64_t v = 0;
    for (int i = 7; i >= 0; --i) v = (v << 8) | (uint64_t)p[i];
    return v;
}

static void reject(const char *why) {
    printf("REJECT %s\n", why);
    exit(1);
}

int main(int argc, char **argv) {
    FILE *f = stdin;
    if (argc >= 2) {
        f = fopen(argv[1], "rb");
        if (!f) { reject("cannot-open-program"); }
    }
    size_t n = fread(prog, 1, MAX_PROG_BYTES + 1, f);
    if (argc >= 2) fclose(f);
    if (n > MAX_PROG_BYTES) { reject("program-too-long"); }

    uint64_t x = (uint64_t)PNK_X0;
    size_t i = 0;
    unsigned steps = 0;

    while (i < n) {
        unsigned char op = prog[i++];
        if (++steps > MAX_STEPS) { reject("too-many-steps"); }
        switch (op) {
            case OP_HALT:
                goto done;
            case OP_TRPL:
                x = x * 3u;
                break;
            case OP_SQ:
                x = x * x;
                break;
            case OP_ADDK:
            case OP_MULK: {
                if (i + 8 > n) { reject("truncated-immediate"); }
                uint64_t imm = load_le64(&prog[i]);
                i += 8;
                if (imm % INV_MOD != 0) { reject("immediate-not-multiple-of-3"); }
                if (op == OP_ADDK) x = x + imm;
                else               x = x * imm;
                break;
            }
            default:
                reject("unknown-opcode");
        }
    }
done:
    if (x == (uint64_t)PNK_TARGET) {
        printf("ACCEPT x=%llu == TARGET\n", (unsigned long long)x);
        return 0;
    }
    printf("REJECT final=%llu != TARGET\n", (unsigned long long)x);
    return 1;
}
