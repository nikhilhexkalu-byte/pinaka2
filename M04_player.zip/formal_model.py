#!/usr/bin/env python3
import sys, re

MAX_PROG_BYTES = 4096
MAX_STEPS = 1024
HALT, TRPL, SQ, ADDK, MULK = 0x00, 0x01, 0x02, 0x10, 0x11
_IMM = {ADDK, MULK}
_ALL = {HALT, TRPL, SQ, ADDK, MULK}

X0 = 0
TARGET = 3205865151537252764


class IllFormed(Exception):
    pass


def decode(program: bytes):
    if len(program) > MAX_PROG_BYTES:
        raise IllFormed("program too long")
    out, i, steps = [], 0, 0
    while i < len(program):
        op = program[i]; i += 1
        if op not in _ALL:
            raise IllFormed("unknown opcode 0x%02x" % op)
        steps += 1
        if steps > MAX_STEPS:
            raise IllFormed("too many steps")
        if op in _IMM:
            if i + 8 > len(program):
                raise IllFormed("truncated immediate")
            imm = int.from_bytes(program[i:i+8], "little"); i += 8
            if imm % 3 != 0:
                raise IllFormed("immediate %d not a multiple of 3" % imm)
            out.append((op, imm))
        else:
            out.append((op, None))
        if op == HALT:
            break
    return out


def run(program: bytes, x0: int = X0):
    x = int(x0)
    for op, imm in decode(program):
        if op == HALT:   break
        elif op == TRPL: x = x * 3
        elif op == SQ:   x = x * x
        elif op == ADDK: x = x + imm
        elif op == MULK: x = x * imm
    return x


def check(program: bytes) -> bool:
    return run(program) == TARGET


def _load(path: str) -> bytes:
    data = open(path, "rb").read()
    txt = data.strip()
    if re.fullmatch(rb"[0-9a-fA-F\s]+", txt) and len(txt) % 2 == 0:
        try:
            return bytes.fromhex(txt.decode())
        except ValueError:
            pass
    return data


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 formal_model.py <program.hex | program.bin>"); sys.exit(2)
    prog = _load(sys.argv[1])
    try:
        final = run(prog)
    except IllFormed as e:
        print("ILL-FORMED:", e); sys.exit(2)
    print("final  =", final)
    print("TARGET =", TARGET)
    print("verdict:", "ACCEPT" if final == TARGET else "REJECT")
